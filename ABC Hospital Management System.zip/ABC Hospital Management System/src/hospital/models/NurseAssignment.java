
package hospital.models;

import java.time.LocalDateTime;

public class NurseAssignment {
    private int id;
    private Nurse nurse;
    private Patient patient;
    private LocalDateTime assingmentDate;
    private LocalDateTime endDate;
    private String shift;
    private String status;
    private String notes;
    private Admission admission;
    
    public NurseAssignment(){
    }

    public int getId() {
        return id;
    }


    public Nurse getNurse() {
        return nurse;
    }

    public void setNurse(Nurse nurse) {
        this.nurse = nurse;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public LocalDateTime getAssingmentDate() {
        return assingmentDate;
    }

    public void setAssingmentDate(LocalDateTime assingmentDate) {
        this.assingmentDate = assingmentDate;
    }

    public LocalDateTime getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDateTime endDate) {
        this.endDate = endDate;
    }

    public String getShift() {
        return shift;
    }

    public void setShift(String shift) {
        this.shift = shift;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public Admission getAdmission() {
        return admission;
    }

    public void setAdmission(Admission admission) {
        this.admission = admission;
    }
    
    
}
