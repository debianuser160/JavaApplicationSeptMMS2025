package mainhospital;

import mainhospital.models.Patient;
import mainhospital.models.Doctor;
import mainhospital.models.Nurse;
import mainhospital.models.Department;
import mainhospital.models.Appointment;
import mainhospital.models.LaboratoryTechnician;
import mainhospital.models.Pharmacist;

import mainhospital.services.PatientService;
import mainhospital.services.DoctorService;
import mainhospital.services.NurseService;
import mainhospital.services.AppointmentService;
import mainhospital.services.UserService;
import mainhospital.services.LaboratoryTechnicianService;
import mainhospital.services.PharmacistService;

import mainhospital.userview.PatientView;
import mainhospital.userview.DoctorView;
import mainhospital.userview.NurseView;
import mainhospital.userview.AppointmentView;
import mainhospital.userview.LaboratoryTechnicianView;
import mainhospital.userview.PharmacistView;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

public class ABCHospitalMainApp {

    private static final Scanner scanner =
            new Scanner(System.in);
    
    // =========================================================
    //USERNAME
    //==========================================================
    
    private static final UserService userService =
            new UserService();

    // =========================================================
    // PATIENT
    // =========================================================

    private static final PatientService patientService =
            new PatientService();

    private static final PatientView patientView =
            new PatientView();


    // =========================================================
    // DOCTOR
    // =========================================================

    private static final DoctorService doctorService =
            new DoctorService();

    private static final DoctorView doctorView =
            new DoctorView();


    // =========================================================
    // NURSE
    // =========================================================

    private static final NurseService nurseService =
            new NurseService();

    private static final NurseView nurseView =
            new NurseView();
    
    // =======================================================
    // LABORATORY TECHNICIAN
    // =======================================================
    
    private static final LaboratoryTechnicianService laboratoryTechnicianService =
        new LaboratoryTechnicianService();

    private static final LaboratoryTechnicianView laboratoryTechnicianView =
        new LaboratoryTechnicianView();

    // =========================================================
    // PHARMACIST
    // =========================================================
    
    private static final PharmacistService pharmacistService=
            new PharmacistService();
    
    private static final PharmacistView pharmacistView =
            new PharmacistView();
    
    // =========================================================
    // APPOINTMENT
    // =========================================================

    private static final AppointmentService appointmentService =
            new AppointmentService();

    private static final AppointmentView appointmentView =
            new AppointmentView();


    // =========================================================
    // DATE FORMATTER
    // =========================================================

    private static final DateTimeFormatter DATE_TIME_FORMATTER =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");


    // =========================================================
    // MAIN
    // =========================================================

    public static void main(String[] args) {

        while (true) {

            displayMainMenu();

            int choice =
                    readInt(
                            "Enter your choice: "
                    );

            switch (choice) {

                case 1:
                    displayMainMenu();
                    break;

                case 2:
                    patientMenu();
                    break;

                case 3:
                    staffMenu();
                    break;

                case 4:
                    appointmentMenu();
                    break;

                case 5:
                    System.out.println(
                            "Admission Management coming soon."
                    );
                    break;

                

                case 7:
                    System.out.println(
                            "Pharmacy Management coming soon."
                    );
                    break;

                case 8:
                    System.out.println(
                            "Billing Management coming soon."
                    );
                    break;

                case 0:

                    System.out.println();

                    System.out.println(
                            "Thank you for using ABC Hospital System."
                    );

                    scanner.close();

                    return;

                default:

                    System.out.println(
                            "Invalid choice."
                    );
            }
        }
    }


    // =========================================================
    // MAIN MENU
    // =========================================================

    private static void displayMainMenu() {

        System.out.println();

        System.out.println(
                "========================================"
        );

        System.out.println(
                "       ABC HOSPITAL MANAGEMENT SYSTEM"
        );

        System.out.println(
                "========================================"
        );
        
        System.out.println(
                "1. Dashboard"
        );

        System.out.println(
                "2. Patient Management"
        );

        System.out.println(
                "3. Staff Management"
        );

        System.out.println(
                "4. Appointment Management"
        );

        System.out.println(
                "5. Admission & Bed Management"
        );

        System.out.println(
                "6. Clinical Management"
        );

        System.out.println(
                "7. Laboratory Services"
        );
        
        System.out.println(
                    "8. Pharmacy Services"
        );

        System.out.println(
                "9. Billing & Payment"
        );

        System.out.println(
                "10. Hospital Administration"
        );

        System.out.println(
                "11. User Account"
        );
        
        System.out.println(
                    "0. Logout"
        );

        System.out.println(
                "========================================"
        );
    }


    // =========================================================
    // PATIENT MENU
    // =========================================================

    private static void patientMenu() {

        while (true) {

            System.out.println();

            System.out.println(
                    "========================================"
            );

            System.out.println(
                    "           PATIENT MANAGEMENT"
            );

            System.out.println(
                    "========================================"
            );

            System.out.println(
                    "1. Register Patient"
            );

            System.out.println(
                    "2. View All Patients"
            );

            System.out.println(
                    "3. Find Patient"
            );

            System.out.println(
                    "4. Update Patient"
            );

            System.out.println(
                    "5. Delete Patient"
            );

            System.out.println(
                    "0. Back"
            );

            System.out.println(
                    "========================================"
            );

            int choice =
                    readInt(
                            "Enter your choice: "
                    );

            switch (choice) {

                case 1:
                    registerPatient();
                    break;

                case 2:
                    viewAllPatients();
                    break;

                case 3:
                    findPatient();
                    break;

                case 4:
                    updatePatient();
                    break;

                case 5:
                    deletePatient();
                    break;

                case 0:
                    return;

                default:
                    System.out.println(
                            "Invalid choice."
                    );
            }
        }
    }


    // =========================================================
    // REGISTER PATIENT
    // =========================================================

    private static void registerPatient() {

        System.out.println();

        System.out.println(
                "========== REGISTER PATIENT =========="
        );

        System.out.print(
                "First Name: "
        );

        String firstName =
                scanner.nextLine();

        System.out.print(
                "Last Name: "
        );

        String lastName =
                scanner.nextLine();

        System.out.print(
                "Gender (M/F): "
        );

        char gender =
                scanner.nextLine()
                        .charAt(0);

        System.out.print(
                "Date of Birth (yyyy-MM-dd): "
        );

        LocalDate dateOfBirth =
                LocalDate.parse(
                        scanner.nextLine()
                );

        System.out.print(
                "Phone: "
        );

        String phone =
                scanner.nextLine();

        System.out.print(
                "Email: "
        );

        String email =
                scanner.nextLine();

        System.out.print(
                "Street: "
        );

        String street =
                scanner.nextLine();

        System.out.print(
                "City: "
        );

        String city =
                scanner.nextLine();

        System.out.print(
                "Country: "
        );

        String country =
                scanner.nextLine();

        System.out.print(
                "Blood Group: "
        );

        String bloodGroup =
                scanner.nextLine();

        System.out.print(
                "Genotype: "
        );

        String genotype =
                scanner.nextLine();

        System.out.print(
                "Allergies: "
        );

        String allergies =
                scanner.nextLine();

        System.out.print(
                "Emergency Contact: "
        );

        String emergencyContact =
                scanner.nextLine();

        System.out.print(
                "Emergency Phone: "
        );

        String emergencyPhone =
                scanner.nextLine();

        Patient patient =
                new Patient(
                        0,
                        bloodGroup,
                        genotype,
                        allergies,
                        emergencyContact,
                        emergencyPhone,
                        firstName,
                        lastName,
                        gender,
                        dateOfBirth,
                        phone,
                        email,
                        street,
                        city,
                        country
                );

        boolean success =
                patientService.registerPatient(
                        patient
                );

        if (success) {

            System.out.println();

            System.out.println(
                    "Patient registered successfully."
            );

        } else {

            System.out.println();

            System.out.println(
                    "Failed to register patient."
            );
        }
    }


    // =========================================================
    // VIEW ALL PATIENTS
    // =========================================================

    private static void viewAllPatients() {

        List<Patient> patients =
                patientService.getAllPatients();

        patientView.displayPatients(
                patients
        );
    }


    // =========================================================
    // FIND PATIENT
    // =========================================================

    private static void findPatient() {

        int id =
                readInt(
                        "Enter Patient ID: "
                );

        Patient patient =
                patientService.getPatientById(
                        id
                );

        patientView.displayPatient(
                patient
        );
    }


    // =========================================================
    // UPDATE PATIENT
    // =========================================================

    private static void updatePatient() {

        int id =
                readInt(
                        "Enter Patient ID to update: "
                );

        Patient patient =
                patientService.getPatientById(
                        id
                );

        if (patient == null) {

            System.out.println(
                    "Patient not found."
            );

            return;
        }

        System.out.println();

        System.out.println(
                "Enter new patient information."
        );

        System.out.print(
                "First Name: "
        );

        patient.setFirstName(
                scanner.nextLine()
        );

        System.out.print(
                "Last Name: "
        );

        patient.setLastName(
                scanner.nextLine()
        );

        System.out.print(
                "Gender (M/F): "
        );

        patient.setGender(
                scanner.nextLine()
                        .charAt(0)
        );

        System.out.print(
                "Date of Birth (yyyy-MM-dd): "
        );

        patient.setDateOfBirth(
                LocalDate.parse(
                        scanner.nextLine()
                )
        );

        System.out.print(
                "Phone: "
        );

        patient.setPhone(
                scanner.nextLine()
        );

        System.out.print(
                "Email: "
        );

        patient.setEmail(
                scanner.nextLine()
        );

        System.out.print(
                "Street: "
        );

        patient.setStreet(
                scanner.nextLine()
        );

        System.out.print(
                "City: "
        );

        patient.setCity(
                scanner.nextLine()
        );

        System.out.print(
                "Country: "
        );

        patient.setCountry(
                scanner.nextLine()
        );

        System.out.print(
                "Blood Group: "
        );

        patient.setBloodGroup(
                scanner.nextLine()
        );

        System.out.print(
                "Genotype: "
        );

        patient.setGenotype(
                scanner.nextLine()
        );

        System.out.print(
                "Allergies: "
        );

        patient.setAllergies(
                scanner.nextLine()
        );

        System.out.print(
                "Emergency Contact: "
        );

        patient.setEmergencyContact(
                scanner.nextLine()
        );

        System.out.print(
                "Emergency Phone: "
        );

        patient.setEmergencyPhone(
                scanner.nextLine()
        );

        boolean success =
                patientService.updatePatient(
                        patient
                );

        if (success) {

            System.out.println(
                    "Patient updated successfully."
            );

        } else {

            System.out.println(
                    "Patient update failed."
            );
        }
    }


    // =========================================================
    // DELETE PATIENT
    // =========================================================

    private static void deletePatient() {

        int id =
                readInt(
                        "Enter Patient ID to delete: "
                );

        Patient patient =
                patientService.getPatientById(
                        id
                );

        if (patient == null) {

            System.out.println(
                    "Patient not found."
            );

            return;
        }

        patientView.displayPatient(
                patient
        );

        System.out.print(
                "Are you sure you want to delete this patient? (Y/N): "
        );

        String answer =
                scanner.nextLine();

        if (!answer.equalsIgnoreCase("Y")) {

            System.out.println(
                    "Delete cancelled."
            );

            return;
        }

        boolean success =
                patientService.deletePatient(
                        id
                );

        if (success) {

            System.out.println(
                    "Patient deleted successfully."
            );

        } else {

            System.out.println(
                    "Patient deletion failed."
            );
        }
    }
    
    //=========================================================
    //STAFF MENU
    //=========================================================
    
    private static void staffMenu(){
        
        while (true) {
            System.out.println();
            System.out.println("==========================================");
            System.out.println("            STAFF MANAGEMENT"
            );
            System.out.println("=============================="
            );
            System.out.println("1. Doctor Management");
            System.out.println("2. Nurse Management");
            System.out.println("3. Laboratory Technician Management");   
            System.out.println("4. Pharmacist Management");  
            System.out.println("5. View All Staff");
            System.out.println("6. Find Staff");
            System.out.println("7. View Staff By Department");
            System.out.println("8. Staff Account Management");
            System.out.println("0. Back");
            
            int choice = readInt("Enter your choice: ");
            
            switch (choice) {
                
                case 1:
                    doctorMenu();
                    break;
                    
                case 2:
                    nurseMenu();
                    break;
                    
                case 3:
                    laboratoryTechnicianMenu();
                    break;
                    
                case 4:
                    pharmacistMenu();
                    break;
                    
                case 5:
                    viewAllStaffMenu();
                    break;
                //case 6:
                  //  findStaffMenu();
                    //break;
                    
                //case 7:
                    
                    
                    
                    
                case 0:
                    return;
                    
                default:
                    System.out.println("Invalid choice.");
            }
            
        }
    }


    // =========================================================
    // DOCTOR MENU
    // =========================================================

    private static void doctorMenu() {

        while (true) {

            System.out.println();

            System.out.println(
                    "========================================"
            );

            System.out.println(
                                    
                    "           DOCTOR MANAGEMENT"
            );

            System.out.println(
                    "========================================"
            );

            System.out.println(
                    "1. Register Doctor"
            );

            System.out.println(
                    "2. View All Doctors"
            );

            System.out.println(
                    "3. Find Doctor"
            );

            System.out.println(
                    "4. Update Doctor"
            );

            System.out.println(
                    "5. Delete Doctor"
            );

            System.out.println(
                    "0. Back"
            );

            System.out.println(
                    "========================================"
            );

            int choice =
                    readInt(
                            "Enter your choice: "
                    );

            switch (choice) {

                case 1:
                    registerDoctor();
                    break;

                case 2:
                    viewAllDoctors();
                    break;

                case 3:
                    findDoctor();
                    break;

                case 4:
                    updateDoctor();
                    break;

                case 5:
                    deleteDoctor();
                    break;

                case 0:
                    return;

                default:
                    System.out.println(
                            "Invalid choice."
                    );
            }
        }
    }


    // =========================================================
    // REGISTER DOCTOR
    // =========================================================

    private static void registerDoctor() {

        System.out.println();

        System.out.println(
                "========== REGISTER DOCTOR =========="
        );

        System.out.print(
                "First Name: "
        );

        String firstName =
                scanner.nextLine();

        System.out.print(
                "Last Name: "
        );

        String lastName =
                scanner.nextLine();

        System.out.print(
                "Gender (M/F): "
        );

        char gender =
                scanner.nextLine()
                        .charAt(0);

        System.out.print(
                "Date of Birth (yyyy-MM-dd): "
        );

        LocalDate dateOfBirth =
                LocalDate.parse(
                        scanner.nextLine()
                );

        System.out.print(
                "Phone: "
        );

        String phone =
                scanner.nextLine();

        System.out.print(
                "Email: "
        );

        String email =
                scanner.nextLine();

        System.out.print(
                "Street: "
        );

        String street =
                scanner.nextLine();

        System.out.print(
                "City: "
        );

        String city =
                scanner.nextLine();

        System.out.print(
                "Country: "
        );

        String country =
                scanner.nextLine();


        System.out.print(
                "Employment Date (yyyy-MM-dd): "
        );

        LocalDate employmentDate =
                LocalDate.parse(
                        scanner.nextLine()
                );

        System.out.print(
                "Salary: "
        );

        double salary =
                Double.parseDouble(
                        scanner.nextLine()
                );


        int departmentId =  
                readInt(
                        "Department ID: "
                );

        System.out.print(
                "Department Name: "
        );

        String departmentName =
                scanner.nextLine();

        Department department =
                new Department();

        department.setId(
                departmentId
        );

        department.setName(
                departmentName
        );


        System.out.print(
                "Specialization: "
        );

        String specialization =
                scanner.nextLine();

        System.out.print(
                "License Number: "
        );

        String licenseNumber =
                scanner.nextLine();


        Doctor doctor =
                new Doctor(
                        firstName,
                        lastName,
                        gender,
                        dateOfBirth,
                        phone,
                        email,
                        street,
                        city,
                        country,
                        0,
                        employmentDate,
                        salary,
                        department,
                        specialization,
                        licenseNumber
                );


        boolean success =
                doctorService.registerDoctor(
                        doctor
                );

        if (success) {

            System.out.println();

            System.out.println(
                    "Doctor registered successfully."
            );

        } else {

            System.out.println();

            System.out.println(
                    "Failed to register doctor."
            );
        }
    }


    // =========================================================
    // VIEW ALL DOCTORS
    // =========================================================

    private static void viewAllDoctors() {

        List<Doctor> doctors =
                doctorService.getAllDoctors();

        doctorView.displayDoctors(
                doctors
        );
    }


    // =========================================================
    // FIND DOCTOR
    // =========================================================

    private static void findDoctor() {

        int id =
                readInt(
                        "Enter Doctor/Staff ID: "
                );

        Doctor doctor =
                doctorService.getDoctorById(
                        id
                );

        doctorView.displayDoctor(
                doctor
        );
    }


    // =========================================================
    // UPDATE DOCTOR
    // =========================================================

    private static void updateDoctor() {

        int id =
                readInt(
                        "Enter Doctor/Staff ID to update: "
                );

        Doctor doctor =
                doctorService.getDoctorById(
                        id
                );

        if (doctor == null) {

            System.out.println(
                    "Doctor not found."
            );

            return;
        }

        System.out.println();

        doctorView.displayDoctor(
                doctor
        );

        System.out.println();

        System.out.println(
                "Enter new doctor information."
        );


        System.out.print(
                "First Name: "
        );

        doctor.setFirstName(
                scanner.nextLine()
        );

        System.out.print(
                "Last Name: "
        );

        doctor.setLastName(
                scanner.nextLine()
        );

        System.out.print(
                "Gender (M/F): "
        );

        doctor.setGender(
                scanner.nextLine()
                        .charAt(0)
        );

        System.out.print(
                "Date of Birth (yyyy-MM-dd): "
        );

        doctor.setDateOfBirth(
                LocalDate.parse(
                        scanner.nextLine()
                )
        );

        System.out.print(
                "Phone: "
        );

        doctor.setPhone(
                scanner.nextLine()
        );

        System.out.print(
                "Email: "
        );

        doctor.setEmail(
                scanner.nextLine()
        );

        System.out.print(
                "Street: "
        );

        doctor.setStreet(
                scanner.nextLine()
        );

        System.out.print(
                "City: "
        );

        doctor.setCity(
                scanner.nextLine()
        );

        System.out.print(
                "Country: "
        );

        doctor.setCountry(
                scanner.nextLine()
        );


        System.out.print(
                "Employment Date (yyyy-MM-dd): "
        );

        doctor.setEmploymentDate(
                LocalDate.parse(
                        scanner.nextLine()
                )
        );

        System.out.print(
                "Salary: "
        );

        doctor.setSalary(
                Double.parseDouble(
                        scanner.nextLine()
                )
        );


        int departmentId =
                readInt(
                        "Department ID: "
                );

        System.out.print(
                "Department Name: "
        );

        String departmentName =
                scanner.nextLine();

        Department department =
                new Department();

        department.setId(
                departmentId
        );

        department.setName(
                departmentName
        );

        doctor.setDepartment(
                department
        );


        System.out.print(
                "Specialization: "
        );

        doctor.setSpecialization(
                scanner.nextLine()
        );

        System.out.print(
                "License Number: "
        );

        doctor.setLicenseNumber(
                scanner.nextLine()
        );


        boolean success =
                doctorService.updateDoctor(
                        doctor
                );

        if (success) {

            System.out.println();

            System.out.println(
                    "Doctor updated successfully."
            );

        } else {

            System.out.println();

            System.out.println(
                    "Doctor update failed."
            );
        }
    }


    // =========================================================
    // DELETE DOCTOR
    // =========================================================

    private static void deleteDoctor() {

        int id =
                readInt(
                        "Enter Doctor/Staff ID to delete: "
                );

        Doctor doctor =
                doctorService.getDoctorById(
                        id
                );

        if (doctor == null) {

            System.out.println(
                    "Doctor not found."
            );

            return;
        }

        doctorView.displayDoctor(
                doctor
        );

        System.out.print(
                "Are you sure you want to delete this doctor? (Y/N): "
        );

        String answer =
                scanner.nextLine();

        if (!answer.equalsIgnoreCase("Y")) {

            System.out.println(
                    "Delete cancelled."
            );

            return;
        }

        boolean success =
                doctorService.deleteDoctor(
                        id
                );

        if (success) {

            System.out.println(
                    "Doctor deleted successfully."
            );

        } else {

            System.out.println(
                    "Doctor deletion failed."
            );
        }
    }


    // =========================================================
    // NURSE MENU
    // =========================================================

    private static void nurseMenu() {

        while (true) {

            System.out.println();

            System.out.println(
                    "========================================"
            );

            System.out.println(
                    "            NURSE MANAGEMENT"
            );

            System.out.println(
                    "========================================"
            );

            System.out.println(
                    "1. Register Nurse"
            );

            System.out.println(
                    "2. View All Nurses"
            );

            System.out.println(
                    "3. Find Nurse"
            );

            System.out.println(
                    "4. Update Nurse"
            );

            System.out.println(
                    "5. Delete Nurse"
            );

            System.out.println(
                    "0. Back"
            );

            System.out.println(
                    "========================================"
            );

            int choice =
                    readInt(
                            "Enter your choice: "
                    );

            switch (choice) {

                case 1:
                    registerNurse();
                    break;

                case 2:
                    viewAllNurses();
                    break;

                case 3:
                    findNurse();
                    break;

                case 4:
                    updateNurse();
                    break;

                case 5:
                    deleteNurse();
                    break;

                case 0:
                    return;

                default:
                    System.out.println(
                            "Invalid choice."
                    );
            }
        }
    }


    // =========================================================
    // REGISTER NURSE
    // =========================================================

    private static void registerNurse() {

        System.out.println();

        System.out.println(
                "========== REGISTER NURSE =========="
        );

        System.out.println();

        System.out.println(
                "----- PERSONAL INFORMATION -----"
        );

        System.out.print(
                "First Name: "
        );

        String firstName =
                scanner.nextLine();

        System.out.print(
                "Last Name: "
        );

        String lastName =
                scanner.nextLine();

        System.out.print(
                "Gender (M/F): "
        );

        char gender =
                scanner.nextLine()
                        .charAt(0);

        System.out.print(
                "Date of Birth (yyyy-MM-dd): "
        );

        LocalDate dateOfBirth =
                LocalDate.parse(
                        scanner.nextLine()
                );

        System.out.print(
                "Phone: "
        );

        String phone =
                scanner.nextLine();

        System.out.print(
                "Email: "
        );

        String email =
                scanner.nextLine();

        System.out.print(
                "Street: "
        );

        String street =
                scanner.nextLine();

        System.out.print(
                "City: "
        );

        String city =
                scanner.nextLine();

        System.out.print(
                "Country: "
        );

        String country =
                scanner.nextLine();


        System.out.println();

        System.out.println(
                "----- STAFF INFORMATION -----"
        );

        System.out.print(
                "Employment Date (yyyy-MM-dd): "
        );

        LocalDate employmentDate =
                LocalDate.parse(
                        scanner.nextLine()
                );

        System.out.print(
                "Salary: "
        );

        double salary =
                Double.parseDouble(
                        scanner.nextLine()
                );


        System.out.println();

        System.out.println(
                "----- DEPARTMENT INFORMATION -----"
        );

        int departmentId =
                readInt(
                        "Department ID: "
                );

        System.out.print(
                "Department Name: "
        );

        String departmentName =
                scanner.nextLine();

        Department department =
                new Department();

        department.setId(
                departmentId
        );

        department.setName(
                departmentName
        );


        System.out.println();

        System.out.println(
                "----- NURSE INFORMATION -----"
        );

        System.out.print(
                "Nursing License: "
        );

        String nursingLicense =
                scanner.nextLine();

        System.out.print(
                "Qualification: "
        );

        String qualification =
                scanner.nextLine();


        Nurse nurse =
                new Nurse(
                        firstName,
                        lastName,
                        gender,
                        dateOfBirth,
                        phone,
                        email,
                        street,
                        city,
                        country,
                        0,
                        employmentDate,
                        salary,
                        department,
                        nursingLicense,
                        qualification
                );


        boolean success =
                nurseService.registerNurse(
                        nurse
                );

        if (success) {

            System.out.println();

            System.out.println(
                    "Nurse registered successfully."
            );

        } else {

            System.out.println();

            System.out.println(
                    "Failed to register nurse."
            );
        }
    }


    // =========================================================
    // VIEW ALL NURSES
    // =========================================================

    private static void viewAllNurses() {

        List<Nurse> nurses =
                nurseService.getAllNurses();

        nurseView.displayNurses(
                nurses
        );
    }


    // =========================================================
    // FIND NURSE
    // =========================================================

    private static void findNurse() {

        int staffId =
                readInt(
                        "Enter Nurse/Staff ID: "
                );

        Nurse nurse =
                nurseService.getNurseById(
                        staffId
                );

        nurseView.displayNurse(
                nurse
        );
    }


    // =========================================================
    // UPDATE NURSE
    // =========================================================

    private static void updateNurse() {

        int staffId =
                readInt(
                        "Enter Nurse/Staff ID to update: "
                );

        Nurse nurse =
                nurseService.getNurseById(
                        staffId
                );

        if (nurse == null) {

            System.out.println(
                    "Nurse not found."
            );

            return;
        }


        System.out.println();

        System.out.println(
                "Current nurse information:"
        );

        nurseView.displayNurse(
                nurse
        );


        System.out.println();

        System.out.println(
                "Enter new nurse information."
        );


        System.out.println();

        System.out.println(
                "----- PERSONAL INFORMATION -----"
        );

        System.out.print(
                "First Name: "
        );

        nurse.setFirstName(
                scanner.nextLine()
        );

        System.out.print(
                "Last Name: "
        );

        nurse.setLastName(
                scanner.nextLine()
        );

        System.out.print(
                "Gender (M/F): "
        );

        nurse.setGender(
                scanner.nextLine()
                        .charAt(0)
        );

        System.out.print(
                "Date of Birth (yyyy-MM-dd): "
        );

        nurse.setDateOfBirth(
                LocalDate.parse(
                        scanner.nextLine()
                )
        );

        System.out.print(
                "Phone: "
        );

        nurse.setPhone(
                scanner.nextLine()
        );

        System.out.print(
                "Email: "
        );

        nurse.setEmail(
                scanner.nextLine()
        );

        System.out.print(
                "Street: "
        );

        nurse.setStreet(
                scanner.nextLine()
        );

        System.out.print(
                "City: "
        );

        nurse.setCity(
                scanner.nextLine()
        );

        System.out.print(
                "Country: "
        );

        nurse.setCountry(
                scanner.nextLine()
        );


        System.out.println();

        System.out.println(
                "----- STAFF INFORMATION -----"
        );

        System.out.print(
                "Employment Date (yyyy-MM-dd): "
        );

        nurse.setEmploymentDate(
                LocalDate.parse(
                        scanner.nextLine()
                )
        );

        System.out.print(
                "Salary: "
        );

        nurse.setSalary(
                Double.parseDouble(
                        scanner.nextLine()
                )
        );


        System.out.println();

        System.out.println(
                "----- DEPARTMENT INFORMATION -----"
        );

        int departmentId =
                readInt(
                        "Department ID: "
                );

        System.out.print(
                "Department Name: "
        );

        String departmentName =
                scanner.nextLine();

        Department department =
                new Department();

        department.setId(
                departmentId
        );

        department.setName(
                departmentName
        );

        nurse.setDepartment(
                department
        );


        System.out.println();

        System.out.println(
                "----- NURSE INFORMATION -----"
        );

        System.out.print(
                "Nursing License: "
        );

        nurse.setNursingLicense(
                scanner.nextLine()
        );

        System.out.print(
                "Qualification: "
        );

        nurse.setQualification(
                scanner.nextLine()
        );


        boolean success =
                nurseService.updateNurse(
                        nurse
                );

        if (success) {

            System.out.println();

            System.out.println(
                    "Nurse updated successfully."
            );

        } else {

            System.out.println();

            System.out.println(
                    "Nurse update failed."
            );
        }
    }


    // =========================================================
    // DELETE NURSE
    // =========================================================

    private static void deleteNurse() {

        int staffId =
                readInt(
                        "Enter Nurse/Staff ID to delete: "
                );

        Nurse nurse =
                nurseService.getNurseById(
                        staffId
                );

        if (nurse == null) {

            System.out.println(
                    "Nurse not found."
            );

            return;
        }

        nurseView.displayNurse(
                nurse
        );

        System.out.print(
                "Are you sure you want to delete this nurse? (Y/N): "
        );

        String answer =
                scanner.nextLine();

        if (!answer.equalsIgnoreCase("Y")) {

            System.out.println(
                    "Delete cancelled."
            );

            return;
        }

        boolean success =
                nurseService.deleteNurse(
                        staffId
                );

        if (success) {

            System.out.println(
                    "Nurse deleted successfully."
            );

        } else {

            System.out.println(
                    "Nurse deletion failed."
            );
        }
    }
    
    // =========================================================
// LABORATORY TECHNICIAN MENU
// =========================================================

private static void laboratoryTechnicianMenu() {

    while (true) {

        System.out.println();

        System.out.println(
                "========================================"
        );

        System.out.println(
                "     LABORATORY TECHNICIAN MANAGEMENT"
        );

        System.out.println(
                "========================================"
        );

        System.out.println(
                "1. Register Laboratory Technician"
        );

        System.out.println(
                "2. View All Laboratory Technicians"
        );

        System.out.println(
                "3. Find Laboratory Technician"
        );

        System.out.println(
                "4. Update Laboratory Technician"
        );

        System.out.println(
                "5. Delete Laboratory Technician"
        );

        System.out.println(
                "0. Back"
        );

        System.out.println(
                "========================================"
        );

        int choice =
                readInt(
                        "Enter your choice: "
                );

        switch (choice) {

            case 1:
                registerLaboratoryTechnician();
                break;

            case 2:
                viewAllLaboratoryTechnicians();
                break;

            case 3:
                findLaboratoryTechnician();
                break;

            case 4:
                updateLaboratoryTechnician();
                break;

            case 5:
                deleteLaboratoryTechnician();
                break;

            case 0:
                return;

            default:
                System.out.println(
                        "Invalid choice."
                );
        }
    }
}


// =========================================================
// REGISTER LABORATORY TECHNICIAN
// =========================================================

private static void registerLaboratoryTechnician() {

    System.out.println();

    System.out.println(
            "========== REGISTER LABORATORY TECHNICIAN =========="
    );

    System.out.print(
            "First Name: "
    );

    String firstName =
            scanner.nextLine();

    System.out.print(
            "Last Name: "
    );

    String lastName =
            scanner.nextLine();

    System.out.print(
            "Gender (M/F): "
    );

    char gender =
            scanner.nextLine()
                    .charAt(0);

    System.out.print(
            "Date of Birth (yyyy-MM-dd): "
    );

    LocalDate dateOfBirth =
            LocalDate.parse(
                    scanner.nextLine()
            );

    System.out.print(
            "Phone: "
    );

    String phone =
            scanner.nextLine();

    System.out.print(
            "Email: "
    );

    String email =
            scanner.nextLine();

    System.out.print(
            "Street: "
    );

    String street =
            scanner.nextLine();

    System.out.print(
            "City: "
    );

    String city =
            scanner.nextLine();

    System.out.print(
            "Country: "
    );

    String country =
            scanner.nextLine();


    System.out.print(
            "Employment Date (yyyy-MM-dd): "
    );

    LocalDate employmentDate =
            LocalDate.parse(
                    scanner.nextLine()
            );

    System.out.print(
            "Salary: "
    );

    double salary =
            Double.parseDouble(
                    scanner.nextLine()
            );


    int departmentId =
            readInt(
                    "Department ID: "
            );

    System.out.print(
            "Department Name: "
    );

    String departmentName =
            scanner.nextLine();

    Department department =
            new Department();

    department.setId(
            departmentId
    );

    department.setName(
            departmentName
    );


    System.out.print(
            "Qualification: "
    );

    String qualification =
            scanner.nextLine();

    System.out.print(
            "License Number: "
    );

    String licenseNumber =
            scanner.nextLine();


    LaboratoryTechnician technician =
            new LaboratoryTechnician(
                    firstName,
                    lastName,
                    gender,
                    dateOfBirth,
                    phone,
                    email,
                    street,
                    city,
                    country,
                    0,
                    employmentDate,
                    salary,
                    department,
                    qualification,
                    licenseNumber
            );


    boolean success =
            laboratoryTechnicianService.registerLaboratoryTechnician(
                    technician
            );

    if (success) {

        System.out.println();

        System.out.println(
                "Laboratory technician registered successfully."
        );

    } else {

        System.out.println();

        System.out.println(
                "Failed to register laboratory technician."
        );
    }
}


// =========================================================
// VIEW ALL LABORATORY TECHNICIANS
// =========================================================

private static void viewAllLaboratoryTechnicians() {

    List<LaboratoryTechnician> technicians =
            laboratoryTechnicianService.getAllLaboratoryTechnicians();

    laboratoryTechnicianView.displayLaboratoryTechnicians(
            technicians
    );
}


// =========================================================
// FIND LABORATORY TECHNICIAN
// =========================================================

private static void findLaboratoryTechnician() {

    int id =
            readInt(
                    "Enter Laboratory Technician/Staff ID: "
            );

    LaboratoryTechnician technician =
            laboratoryTechnicianService.getLaboratoryTechnicianById(
                    id
            );

    laboratoryTechnicianView.displayLaboratoryTechnician(
            technician
    );
}


// =========================================================
// UPDATE LABORATORY TECHNICIAN
// =========================================================

private static void updateLaboratoryTechnician() {

    int id =
            readInt(
                    "Enter Laboratory Technician/Staff ID to update: "
            );

    LaboratoryTechnician technician =
            laboratoryTechnicianService.getLaboratoryTechnicianById(
                    id
            );

    if (technician == null) {

        System.out.println(
                "Laboratory technician not found."
        );

        return;
    }

    System.out.println();

    laboratoryTechnicianView.displayLaboratoryTechnician(
            technician
    );

    System.out.println();

    System.out.println(
            "Enter new laboratory technician information."
    );


    System.out.print(
            "First Name: "
    );

    technician.setFirstName(
            scanner.nextLine()
    );

    System.out.print(
            "Last Name: "
    );

    technician.setLastName(
            scanner.nextLine()
    );

    System.out.print(
            "Gender (M/F): "
    );

    technician.setGender(
            scanner.nextLine()
                    .charAt(0)
    );

    System.out.print(
            "Date of Birth (yyyy-MM-dd): "
    );

    technician.setDateOfBirth(
            LocalDate.parse(
                    scanner.nextLine()
            )
    );

    System.out.print(
            "Phone: "
    );

    technician.setPhone(
            scanner.nextLine()
    );

    System.out.print(
            "Email: "
    );

    technician.setEmail(
            scanner.nextLine()
    );

    System.out.print(
            "Street: "
    );

    technician.setStreet(
            scanner.nextLine()
    );

    System.out.print(
            "City: "
    );

    technician.setCity(
            scanner.nextLine()
    );

    System.out.print(
            "Country: "
    );

    technician.setCountry(
            scanner.nextLine()
    );


    System.out.print(
            "Employment Date (yyyy-MM-dd): "
    );

    technician.setEmploymentDate(
            LocalDate.parse(
                    scanner.nextLine()
            )
    );

    System.out.print(
            "Salary: "
    );

    technician.setSalary(
            Double.parseDouble(
                    scanner.nextLine()
            )
    );


    int departmentId =
            readInt(
                    "Department ID: "
            );

    System.out.print(
            "Department Name: "
    );

    String departmentName =
            scanner.nextLine();

    Department department =
            new Department();

    department.setId(
            departmentId
    );

    department.setName(
            departmentName
    );

    technician.setDepartment(
            department
    );


    System.out.print(
            "Qualification: "
    );

    technician.setQualification(
            scanner.nextLine()
    );

    System.out.print(
            "License Number: "
    );

    technician.setLicenseNumber(
            scanner.nextLine()
    );


    boolean success =
            laboratoryTechnicianService.updateLaboratoryTechnician(
                    technician
            );

    if (success) {

        System.out.println();

        System.out.println(
                "Laboratory technician updated successfully."
        );

    } else {

        System.out.println();

        System.out.println(
                "Laboratory technician update failed."
        );
    }
}


// =========================================================
// DELETE LABORATORY TECHNICIAN
// =========================================================

private static void deleteLaboratoryTechnician() {

    int id =
            readInt(
                    "Enter Laboratory Technician/Staff ID to delete: "
            );

    LaboratoryTechnician technician =
            laboratoryTechnicianService.getLaboratoryTechnicianById(
                    id
            );

    if (technician == null) {

        System.out.println(
                "Laboratory technician not found."
        );

        return;
    }

    laboratoryTechnicianView.displayLaboratoryTechnician(
            technician
    );

    System.out.print(
            "Are you sure you want to delete this laboratory technician? (Y/N): "
    );

    String answer =
            scanner.nextLine();

    if (!answer.equalsIgnoreCase("Y")) {

        System.out.println(
                "Delete cancelled."
        );

        return;
    }

    boolean success =
            laboratoryTechnicianService.deleteLaboratoryTechnician(
                    id
            );

    if (success) {

        System.out.println(
                "Laboratory technician deleted successfully."
        );

    } else {

        System.out.println(
                "Laboratory technician deletion failed."
        );
    }
}


// =========================================================
// PHARMACIST MENU
// =========================================================

private static void pharmacistMenu() {

    while (true) {

        System.out.println();

        System.out.println(
                "========================================"
        );

        System.out.println(
                "           PHARMACIST MANAGEMENT"
        );

        System.out.println(
                "========================================"
        );

        System.out.println(
                "1. Register Pharmacist"
        );

        System.out.println(
                "2. View All Pharmacists"
        );

        System.out.println(
                "3. Find Pharmacist"
        );

        System.out.println(
                "4. Update Pharmacist"
        );

        System.out.println(
                "5. Delete Pharmacist"
        );

        System.out.println(
                "0. Back"
        );

        System.out.println(
                "========================================"
        );

        int choice =
                readInt(
                        "Enter your choice: "
                );

        switch (choice) {

            case 1:
                registerPharmacist();
                break;

            case 2:
                viewAllPharmacists();
                break;

            case 3:
                findPharmacist();
                break;

            case 4:
                updatePharmacist();
                break;

            case 5:
                deletePharmacist();
                break;

            case 0:
                return;

            default:
                System.out.println(
                        "Invalid choice."
                );
        }
    }
}


// =========================================================
// REGISTER PHARMACIST
// =========================================================

private static void registerPharmacist() {

    System.out.println();

    System.out.println(
            "========== REGISTER PHARMACIST =========="
    );

    System.out.print(
            "First Name: "
    );

    String firstName =
            scanner.nextLine();

    System.out.print(
            "Last Name: "
    );

    String lastName =
            scanner.nextLine();

    System.out.print(
            "Gender (M/F): "
    );

    char gender =
            scanner.nextLine()
                    .charAt(0);

    System.out.print(
            "Date of Birth (yyyy-MM-dd): "
    );

    LocalDate dateOfBirth =
            LocalDate.parse(
                    scanner.nextLine()
            );

    System.out.print(
            "Phone: "
    );

    String phone =
            scanner.nextLine();

    System.out.print(
            "Email: "
    );

    String email =
            scanner.nextLine();

    System.out.print(
            "Street: "
    );

    String street =
            scanner.nextLine();

    System.out.print(
            "City: "
    );

    String city =
            scanner.nextLine();

    System.out.print(
            "Country: "
    );

    String country =
            scanner.nextLine();


    System.out.print(
            "Employment Date (yyyy-MM-dd): "
    );

    LocalDate employmentDate =
            LocalDate.parse(
                    scanner.nextLine()
            );

    System.out.print(
            "Salary: "
    );

    double salary =
            Double.parseDouble(
                    scanner.nextLine()
            );


    int departmentId =
            readInt(
                    "Department ID: "
            );

    System.out.print(
            "Department Name: "
    );

    String departmentName =
            scanner.nextLine();

    Department department =
            new Department();

    department.setId(
            departmentId
    );

    department.setName(
            departmentName
    );


    System.out.print(
            "Qualification: "
    );

    String qualification =
            scanner.nextLine();

    System.out.print(
            "License Number: "
    );

    String licenseNumber =
            scanner.nextLine();


    Pharmacist pharmacist =
            new Pharmacist(
                    firstName,
                    lastName,
                    gender,
                    dateOfBirth,
                    phone,
                    email,
                    street,
                    city,
                    country,
                    0,
                    employmentDate,
                    salary,
                    department,
                    qualification,
                    licenseNumber
            );


    boolean success =
            pharmacistService.registerPharmacist(
                    pharmacist
            );

    if (success) {

        System.out.println();

        System.out.println(
                "Pharmacist registered successfully."
        );

    } else {

        System.out.println();

        System.out.println(
                "Failed to register pharmacist."
        );
    }
}


// =========================================================
// VIEW ALL PHARMACISTS
// =========================================================

private static void viewAllPharmacists() {

    List<Pharmacist> pharmacists =
            pharmacistService.getAllPharmacists();

    pharmacistView.displayPharmacists(
            pharmacists
    );
}


// =========================================================
// FIND PHARMACIST
// =========================================================

private static void findPharmacist() {

    int id =
            readInt(
                    "Enter Pharmacist/Staff ID: "
            );

    Pharmacist pharmacist =
            pharmacistService.getPharmacistById(
                    id
            );

    pharmacistView.displayPharmacist(
            pharmacist
    );
}


// =========================================================
// UPDATE PHARMACIST
// =========================================================

private static void updatePharmacist() {

    int id =
            readInt(
                    "Enter Pharmacist/Staff ID to update: "
            );

    Pharmacist pharmacist =
            pharmacistService.getPharmacistById(
                    id
            );

    if (pharmacist == null) {

        System.out.println(
                "Pharmacist not found."
        );

        return;
    }

    System.out.println();

    pharmacistView.displayPharmacist(
            pharmacist
    );

    System.out.println();

    System.out.println(
            "Enter new pharmacist information."
    );


    System.out.print(
            "First Name: "
    );

    pharmacist.setFirstName(
            scanner.nextLine()
    );

    System.out.print(
            "Last Name: "
    );

    pharmacist.setLastName(
            scanner.nextLine()
    );

    System.out.print(
            "Gender (M/F): "
    );

    pharmacist.setGender(
            scanner.nextLine()
                    .charAt(0)
    );

    System.out.print(
            "Date of Birth (yyyy-MM-dd): "
    );

    pharmacist.setDateOfBirth(
            LocalDate.parse(
                    scanner.nextLine()
            )
    );

    System.out.print(
            "Phone: "
    );

    pharmacist.setPhone(
            scanner.nextLine()
    );

    System.out.print(
            "Email: "
    );

    pharmacist.setEmail(
            scanner.nextLine()
    );

    System.out.print(
            "Street: "
    );

    pharmacist.setStreet(
            scanner.nextLine()
    );

    System.out.print(
            "City: "
    );

    pharmacist.setCity(
            scanner.nextLine()
    );

    System.out.print(
            "Country: "
    );

    pharmacist.setCountry(
            scanner.nextLine()
    );


    System.out.print(
            "Employment Date (yyyy-MM-dd): "
    );

    pharmacist.setEmploymentDate(
            LocalDate.parse(
                    scanner.nextLine()
            )
    );

    System.out.print(
            "Salary: "
    );

    pharmacist.setSalary(
            Double.parseDouble(
                    scanner.nextLine()
            )
    );


    int departmentId =
            readInt(
                    "Department ID: "
            );

    System.out.print(
            "Department Name: "
    );

    String departmentName =
            scanner.nextLine();

    Department department =
            new Department();

    department.setId(
            departmentId
    );

    department.setName(
            departmentName
    );

    pharmacist.setDepartment(
            department
    );


    System.out.print(
            "Qualification: "
    );

    pharmacist.setQualification(
            scanner.nextLine()
    );

    System.out.print(
            "License Number: "
    );

    pharmacist.setLicenseNumber(
            scanner.nextLine()
    );


    boolean success =
            pharmacistService.updatePharmacist(
                    pharmacist
            );

    if (success) {

        System.out.println();

        System.out.println(
                "Pharmacist updated successfully."
        );

    } else {

        System.out.println();

        System.out.println(
                "Pharmacist update failed."
        );
    }
}


// =========================================================
// DELETE PHARMACIST
// =========================================================

private static void deletePharmacist() {

    int id =
            readInt(
                    "Enter Pharmacist/Staff ID to delete: "
            );

    Pharmacist pharmacist =
            pharmacistService.getPharmacistById(
                    id
            );

    if (pharmacist == null) {

        System.out.println(
                "Pharmacist not found."
        );

        return;
    }

    pharmacistView.displayPharmacist(
            pharmacist
    );

    System.out.print(
            "Are you sure you want to delete this pharmacist? (Y/N): "
    );

    String answer =
            scanner.nextLine();

    if (!answer.equalsIgnoreCase("Y")) {

        System.out.println(
                "Delete cancelled."
        );

        return;
    }

    boolean success =
            pharmacistService.deletePharmacist(
                    id
            );

    if (success) {

        System.out.println(
                "Pharmacist deleted successfully."
        );

    } else {

        System.out.println(
                "Pharmacist deletion failed."
        );
    }
}

    // =========================================================
    // VIEW ALL STAFF
    // =========================================================

    private static void viewAllStaffMenu() {
        System.out.println("View All Staff - connect StaffService Here");
    }


        // =========================================================
    // APPOINTMENT MENU
    // =========================================================

    private static void appointmentMenu() {

        while (true) {

            System.out.println();

            System.out.println(
                    "========================================"
            );

            System.out.println(
                    "        APPOINTMENT MANAGEMENT"
            );

            System.out.println(
                    "========================================"
            );

            System.out.println(
                    "1. Create Appointment"
            );

            System.out.println(
                    "2. View All Appointments"
            );

            System.out.println(
                    "3. Find Appointment"
            );

            System.out.println(
                    "4. Update Appointment"
            );

            System.out.println(
                    "5. Cancel Appointment"
            );

            System.out.println(
                    "6. Delete Appointment"
            );

            System.out.println(
                    "7. View Patient Appointments"
            );

            System.out.println(
                    "8. View Doctor Appointments"
            );

            System.out.println(
                    "9. Today's Appointments"
            );

            System.out.println(
                    "10. Upcoming Appointments"
            );


            System.out.println(
                    "0. Back"
            );

            System.out.println(
                    "========================================"
            );

            int choice =
                    readInt(
                            "Enter your choice: "
                    );

            switch (choice) {

                case 1:
                    createAppointment();
                    break;

                case 2:
                    viewAllAppointments();
                    break;

                case 3:
                    findAppointment();
                    break;

                case 4:
                    updateAppointment();
                    break;

                case 5:
                    cancelAppointment();
                    break;

                case 6:
                    deleteAppointment();
                    break;

                case 7:
                    viewPatientAppointments();
                    break;

                case 8:
                    viewDoctorAppointments();
                    break;

                case 9:
                    viewTodaysAppointments();
                    break;

                case 10:
                    viewUpcomingAppointments();
                    break;

                case 0:
                    return;

                default:
                    System.out.println(
                            "Invalid choice."
                    );
            }
        }
    }


    // =========================================================
    // CREATE APPOINTMENT
    // =========================================================

    private static void createAppointment() {

        System.out.println();

        System.out.println(
                "========== CREATE APPOINTMENT =========="
        );


        // =====================================================
        // PATIENT
        // =====================================================

        int patientId =
                readInt(
                        "Enter Patient ID: "
                );

        Patient patient =
                patientService.getPatientById(
                        patientId
                );

        if (patient == null) {

            System.out.println(
                    "Patient not found."
            );

            return;
        }

        System.out.println();

        System.out.println(
                "Patient: "
                        + patient.getFirstName()
                        + " "
                        + patient.getLastName()
        );


        // =====================================================
        // DOCTOR
        // =====================================================

        int doctorId =
                readInt(
                        "Enter Doctor/Staff ID: "
                );

        Doctor doctor =
                doctorService.getDoctorById(
                        doctorId
                );

        if (doctor == null) {

            System.out.println(
                    "Doctor not found."
            );

            return;
        }

        System.out.println();

        System.out.println(
                "Doctor: Dr. "
                        + doctor.getFirstName()
                        + " "
                        + doctor.getLastName()
        );

        System.out.println(
                "Specialization: "
                        + doctor.getSpecialization()
        );


        // =====================================================
        // APPOINTMENT DATE
        // =====================================================

        System.out.println();

        System.out.println(
                "Date format: yyyy-MM-dd HH:mm"
        );

        System.out.print(
                "Appointment Date: "
        );

        String dateInput =
                scanner.nextLine();

        LocalDateTime appointmentDate;

        try {

            appointmentDate =
                    LocalDateTime.parse(
                            dateInput,
                            DATE_TIME_FORMATTER
                    );

        } catch (Exception e) {

            System.out.println(
                    "Invalid date/time format."
            );

            System.out.println(
                    "Please use: yyyy-MM-dd HH:mm"
            );

            return;
        }


        // =====================================================
        // REASON
        // =====================================================

        System.out.print(
                "Reason for Appointment: "
        );

        String reason =
                scanner.nextLine();


        // =====================================================
        // STATUS
        // =====================================================

        String status =
                selectAppointmentStatus();

        if (status == null) {
            return;
        }


        // =====================================================
        // NOTES
        // =====================================================

        System.out.print(
                "Notes: "
        );

        String notes =
                scanner.nextLine();


        // =====================================================
        // CREATE OBJECT
        // =====================================================

        Appointment appointment =
                new Appointment();

        // ID is generated by SQL Server.
        // Do not set the ID manually.

        appointment.setPatient(
                patient
        );

        appointment.setDoctor(
                doctor
        );

        appointment.setAppointmentDate(
                appointmentDate
        );

        appointment.setReason(
                reason
        );

        appointment.setStatus(
                status
        );

        appointment.setNotes(
                notes
        );


        // =====================================================
        // SAVE
        // =====================================================

        boolean success =
                appointmentService.addAppointment(
                        appointment
                );

        if (success) {

            System.out.println();

            System.out.println(
                    "Appointment created successfully."
            );

            if (appointment.getId() > 0) {

                System.out.println(
                        "Appointment ID: "
                                + appointment.getId()
                );
            }

        } else {

            System.out.println();

            System.out.println(
                    "Failed to create appointment."
            );
        }
    }


    // =========================================================
    // SELECT APPOINTMENT STATUS
    // =========================================================

    private static String selectAppointmentStatus() {

        System.out.println();

        System.out.println(
                "Appointment Status"
        );

        System.out.println(
                "1. Scheduled"
        );

        System.out.println(
                "2. Completed"
        );

        System.out.println(
                "3. Cancelled"
        );

        System.out.println(
                "4. Pending"
        );

        int choice =
                readInt(
                        "Select status: "
                );

        switch (choice) {

            case 1:
                return "Scheduled";

            case 2:
                return "Completed";

            case 3:
                return "Cancelled";

            case 4:
                return "Pending";

            default:

                System.out.println(
                        "Invalid status."
                );

                return null;
        }
    }


    // =========================================================
    // VIEW ALL APPOINTMENTS
    // =========================================================

    private static void viewAllAppointments() {

        List<Appointment> appointments =
                appointmentService.getAllAppointments();

        appointmentView.displayAppointments(
                appointments
        );
    }


    // =========================================================
    // FIND APPOINTMENT
    // =========================================================

    private static void findAppointment() {

        int appointmentId =
                readInt(
                        "Enter Appointment ID: "
                );

        Appointment appointment =
                appointmentService.getAppointmentById(
                        appointmentId
                );

        appointmentView.displayAppointment(
                appointment
        );
    }


    // =========================================================
    // UPDATE APPOINTMENT
    // =========================================================

    private static void updateAppointment() {

        int appointmentId =
                readInt(
                        "Enter Appointment ID to update: "
                );

        Appointment appointment =
                appointmentService.getAppointmentById(
                        appointmentId
                );

        if (appointment == null) {

            System.out.println(
                    "Appointment not found."
            );

            return;
        }

        System.out.println();

        System.out.println(
                "Current appointment information:"
        );

        appointmentView.displayAppointment(
                appointment
        );


        // =====================================================
        // PATIENT
        // =====================================================

        int patientId =
                readInt(
                        "Enter new Patient ID: "
                );

        Patient patient =
                patientService.getPatientById(
                        patientId
                );

        if (patient == null) {

            System.out.println(
                    "Patient not found."
            );

            return;
        }

        appointment.setPatient(
                patient
        );


        // =====================================================
        // DOCTOR
        // =====================================================

        int doctorId =
                readInt(
                        "Enter new Doctor/Staff ID: "
                );

        Doctor doctor =
                doctorService.getDoctorById(
                        doctorId
                );

        if (doctor == null) {

            System.out.println(
                    "Doctor not found."
            );

            return;
        }

        appointment.setDoctor(
                doctor
        );


        // =====================================================
        // DATE
        // =====================================================

        System.out.println();

        System.out.println(
                "Date format: yyyy-MM-dd HH:mm"
        );

        System.out.print(
                "Appointment Date: "
        );

        String dateInput =
                scanner.nextLine();

        try {

            appointment.setAppointmentDate(
                    LocalDateTime.parse(
                            dateInput,
                            DATE_TIME_FORMATTER
                    )
            );

        } catch (Exception e) {

            System.out.println(
                    "Invalid date/time format."
            );

            System.out.println(
                    "Please use: yyyy-MM-dd HH:mm"
            );

            return;
        }


        // =====================================================
        // REASON
        // =====================================================

        System.out.print(
                "Reason: "
        );

        appointment.setReason(
                scanner.nextLine()
        );


        // =====================================================
        // STATUS
        // =====================================================

        String status =
                selectAppointmentStatus();

        if (status == null) {
            return;
        }

        appointment.setStatus(
                status
        );


        // =====================================================
        // NOTES
        // =====================================================

        System.out.print(
                "Notes: "
        );

        appointment.setNotes(
                scanner.nextLine()
        );


        // =====================================================
        // UPDATE
        // =====================================================

        boolean success =
                appointmentService.updateAppointment(
                        appointment
                );

        if (success) {

            System.out.println();

            System.out.println(
                    "Appointment updated successfully."
            );

        } else {

            System.out.println();

            System.out.println(
                    "Appointment update failed."
            );
        }
    }


    // =========================================================
    // CANCEL APPOINTMENT
    // =========================================================

    private static void cancelAppointment() {

        int appointmentId =
                readInt(
                        "Enter Appointment ID to cancel: "
                );

        Appointment appointment =
                appointmentService.getAppointmentById(
                        appointmentId
                );

        if (appointment == null) {

            System.out.println(
                    "Appointment not found."
            );

            return;
        }

        appointmentView.displayAppointment(
                appointment
        );

        System.out.print(
                "Are you sure you want to cancel this appointment? (Y/N): "
        );

        String answer =
                scanner.nextLine();

        if (!answer.equalsIgnoreCase("Y")) {

            System.out.println(
                    "Cancel aborted."
            );

            return;
        }

        boolean success =
                appointmentService.cancelAppointment(
                        appointmentId
                );

        if (success) {

            System.out.println(
                    "Appointment cancelled successfully."
            );

        } else {

            System.out.println(
                    "Failed to cancel appointment."
            );
        }
    }


    // =========================================================
    // DELETE APPOINTMENT
    // =========================================================

    private static void deleteAppointment() {

        int appointmentId =
                readInt(
                        "Enter Appointment ID to delete: "
                );

        Appointment appointment =
                appointmentService.getAppointmentById(
                        appointmentId
                );

        if (appointment == null) {

            System.out.println(
                    "Appointment not found."
            );

            return;
        }

        appointmentView.displayAppointment(
                appointment
        );

        System.out.print(
                "Are you sure you want to delete this appointment? (Y/N): "
        );

        String answer =
                scanner.nextLine();

        if (!answer.equalsIgnoreCase("Y")) {

            System.out.println(
                    "Delete cancelled."
            );

            return;
        }

        boolean success =
                appointmentService.deleteAppointment(
                        appointmentId
                );

        if (success) {

            System.out.println(
                    "Appointment deleted successfully."
            );

        } else {

            System.out.println(
                    "Appointment deletion failed."
            );
        }
    }


    // =========================================================
    // VIEW PATIENT APPOINTMENTS
    // =========================================================

    private static void viewPatientAppointments() {

        int patientId =
                readInt(
                        "Enter Patient ID: "
                );

        Patient patient =
                patientService.getPatientById(
                        patientId
                );

        if (patient == null) {

            System.out.println(
                    "Patient not found."
            );

            return;
        }

        System.out.println();

        System.out.println(
                "Appointments for "
                        + patient.getFirstName()
                        + " "
                        + patient.getLastName()
        );

        List<Appointment> appointments =
                appointmentService.getAppointmentsByPatient(
                        patientId
                );

        appointmentView.displayAppointments(
                appointments
        );
    }


    // =========================================================
    // VIEW DOCTOR APPOINTMENTS
    // =========================================================

    private static void viewDoctorAppointments() {

        int doctorId =
                readInt(
                        "Enter Doctor/Staff ID: "
                );

        Doctor doctor =
                doctorService.getDoctorById(
                        doctorId
                );

        if (doctor == null) {

            System.out.println(
                    "Doctor not found."
            );

            return;
        }

        System.out.println();

        System.out.println(
                "Appointments for Dr. "
                        + doctor.getFirstName()
                        + " "
                        + doctor.getLastName()
        );

        List<Appointment> appointments =
                appointmentService.getAppointmentsByDoctor(
                        doctorId
                );

        appointmentView.displayAppointments(
                appointments
        );
    }


    // =========================================================
    // VIEW TODAY'S APPOINTMENTS
    // =========================================================

    private static void viewTodaysAppointments() {

        List<Appointment> appointments =
                appointmentService.getTodaysAppointments();

        System.out.println();

        System.out.println(
                "Today's Appointments:"
        );

        appointmentView.displayAppointments(
                appointments
        );
    }


    // =========================================================
    // VIEW UPCOMING APPOINTMENTS
    // =========================================================

    private static void viewUpcomingAppointments() {

        List<Appointment> appointments =
                appointmentService.getUpcomingAppointments();

        System.out.println();

        System.out.println(
                "Upcoming Appointments:"
        );

        appointmentView.displayAppointments(
                appointments
        );
    }


    // =========================================================
    // READ INTEGER
    // =========================================================

    private static int readInt(
            String message
    ) {

        while (true) {

            try {

                System.out.print(
                        message
                );

                return Integer.parseInt(
                        scanner.nextLine()
                );

            } catch (NumberFormatException e) {

                System.out.println(
                        "Please enter a valid number."
                );
            }
        }
    }
}