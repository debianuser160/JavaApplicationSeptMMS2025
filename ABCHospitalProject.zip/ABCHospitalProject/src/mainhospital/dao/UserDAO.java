
package mainhospital.dao;

import mainhospital.database.DatabaseConnection;
import mainhospital.models.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDAO {

    public User findByUsername(String username) {

        String userSql = "SELECT UserId,"
                + " Username,"
                + " PasswordHash,"
                + " Role,"
                + " StaffId,"
                + " IsActive"
                + " FROM Users WHERE Username = ?";


        try {
            Connection connection = DatabaseConnection.getConnection();
            PreparedStatement statement =
                    connection.prepareStatement(userSql);
            statement.setString(1, username);

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                int id = resultSet.getInt("UserId");
                String foundUsername = resultSet.getString("Username");
                String password = resultSet.getString("Password");
                boolean active = resultSet.getBoolean("Active");

                connection.close();
                return new User(id, foundUsername, password, null, null, active);
            }

            connection.close();

        } catch (SQLException e) {
            System.out.println("Error finding user: " + e.getMessage());
        }

        return null;
    }
}

