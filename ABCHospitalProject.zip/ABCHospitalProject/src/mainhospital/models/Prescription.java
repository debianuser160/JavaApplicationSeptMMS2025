
package mainhospital.models;

import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;

public class Prescription {
    private int id;
    private Patient patient;
    private Doctor doctor;
    private LocalDate prescriptionDate;
    
    private List<PrescriptionItem> items = new ArrayList<>();
    
    public void addItem(PrescriptionItem item){
        items.add(item);
    }
    
    public void removeItem(PrescriptionItem item){
        items.remove(item);
    }
    
    public List<PrescriptionItem> getItems(){
        return items;
    }

    public int getId() {
        return id;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public LocalDate getPrescriptionDate() {
        return prescriptionDate;
    }

    public void setPrescriptionDate(LocalDate prescriptionDate) {
        this.prescriptionDate = prescriptionDate;
    }
    
    
}
