
package mainhospital.services;



import mainhospital.dao.UserDAO;
import mainhospital.models.User;

public class UserService {

    private final UserDAO userDAO;

    public UserService() {
        userDAO = new UserDAO();
    }

    public User login(String username, String password) {

        User user = userDAO.findByUsername(username);

        if (user == null) {
            System.out.println("Username not found.");
            return null;
        }

        if (!user.isActive()) {
            System.out.println("This account is inactive.");
            return null;
        }

        if (!user.getPasswordHash().equals(password)) {
            System.out.println("Incorrect password.");
            return null;
        }

        return user;
    }
}


