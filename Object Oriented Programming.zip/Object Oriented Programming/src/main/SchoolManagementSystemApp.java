
package main;


import java.time.LocalDate;
import school.Student;


public class SchoolManagementSystemApp {
    public static void main(String[] args){
        Student s1 = new Student(1,"Henry","James", 'M',
        LocalDate.parse("2000-09-15"), "080675741234");
        
        System.out.println(s1.getFirstName() + " " + s1.getLastName());
        
        s1.setFirstName("John");
        
        s1.displayStudentInfo();
        
        System.out.println("====================");
        
        Student s2 = new Student(2,"Lucy","Goosy", 'F',
        LocalDate.parse("2008-03-25"), "080675541234");
        
        s2.displayStudentInfo();
        
        System.out.println("====================");
    }
}
